import React, { useState, useEffect, useContext, createContext } from 'react';
import './HooksComponents.css';

// 7.3. Создание контекста для темы
const ThemeContext = createContext();

// 6.1. Счётчик с хуками
const CounterWithHooks = () => {
  const [count, setCount] = useState(0);

  return (
    <div className="counter-hooks">
      <h3>🎣 Счётчик с хуками</h3>
      <div className="count-value">{count}</div>
      <div className="counter-buttons">
        <button className="btn btn-secondary" onClick={() => setCount(count - 1)}>
          ➖ Уменьшить
        </button>
        <button className="btn btn-secondary" onClick={() => setCount(0)}>
          🔄 Сбросить
        </button>
        <button className="btn btn-primary" onClick={() => setCount(count + 1)}>
          ➕ Увеличить
        </button>
      </div>
    </div>
  );
};

// 6.2. Профиль пользователя с useState
const UserProfile = () => {
  const [user, setUser] = useState({
    name: 'Камола Юсупова',
    email: 'kamola@gmail.com',
    age: 17,
    group: '319',
    bio: 'Студентка, изучаю React'
  });

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(user);

  const handleEdit = () => {
    setIsEditing(true);
    setFormData(user);
  };

  const handleSave = () => {
    setUser(formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData(user);
    setIsEditing(false);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="user-profile">
      <h3>👤 Профиль пользователя</h3>
      
      {!isEditing ? (
        <div className="profile-view">
          <div className="profile-info">
            <p><strong>Имя:</strong> {user.name}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Возраст:</strong> {user.age}</p>
            <p><strong>Группа:</strong> {user.group}</p>
            <p><strong>О себе:</strong> {user.bio}</p>
          </div>
          <button className="btn btn-primary" onClick={handleEdit}>
            ✏️ Редактировать
          </button>
        </div>
      ) : (
        <div className="profile-edit">
          <div className="form-group">
            <label>Имя:</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Возраст:</label>
            <input
              type="number"
              name="age"
              value={formData.age}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Группа:</label>
            <input
              type="text"
              name="group"
              value={formData.group}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>О себе:</label>
            <textarea
              name="bio"
              value={formData.bio}
              onChange={handleChange}
              rows="3"
            />
          </div>
          <div className="edit-buttons">
            <button className="btn btn-primary" onClick={handleSave}>
              💾 Сохранить
            </button>
            <button className="btn btn-secondary" onClick={handleCancel}>
              ❌ Отмена
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// 6.3. Демонстрация useEffect
const EffectDemo = () => {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState('');
  const [isVisible, setIsVisible] = useState(true);

  // useEffect без зависимостей (componentDidMount)
  useEffect(() => {
    console.log('Компонент смонтирован');
    setMessage('Добро пожаловать!');

    return () => {
      console.log('Компонент будет размонтирован');
    };
  }, []);

  // useEffect с зависимостью (componentDidUpdate)
  useEffect(() => {
    if (count > 0) {
      setMessage(`Счётчик обновлён: ${count}`);
    }
  }, [count]);

  // useEffect для обработки видимости
  useEffect(() => {
    if (!isVisible) {
      const timer = setTimeout(() => {
        setIsVisible(true);
        setMessage('Элемент снова видим!');
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  return (
    <div className="effect-demo">
      <h3>🔄 Демонстрация useEffect</h3>
      
      <div className="demo-section">
        <h4>Счётчик: {count}</h4>
        <div className="button-group">
          <button className="btn btn-primary" onClick={() => setCount(count + 1)}>
            ➕ Увеличить
          </button>
          <button className="btn btn-secondary" onClick={() => setCount(0)}>
            🔄 Сбросить
          </button>
        </div>
      </div>

      <div className="demo-section">
        <h4>Сообщение:</h4>
        <div className="message-box">{message}</div>
      </div>

      <div className="demo-section">
        <h4>Видимость элемента:</h4>
        <button 
          className="btn btn-secondary"
          onClick={() => setIsVisible(false)}
          disabled={!isVisible}
        >
          {isVisible ? '👁️ Скрыть элемент' : '⏳ Таймер...'}
        </button>
        {isVisible && (
          <div className="visible-element">
            🎉 Я видимый элемент!
          </div>
        )}
      </div>
    </div>
  );
};

// 7.1. Кастомный хук useLocalStorage
const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Ошибка чтения localStorage ключа "${key}":`, error);
      return initialValue;
    }
  });

  const setValue = (value) => {
    try {
      setStoredValue(value);
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Ошибка записи в localStorage ключа "${key}":`, error);
    }
  };

  return [storedValue, setValue];
};

// Компонент с useLocalStorage
const LocalStorageDemo = () => {
  const [name, setName] = useLocalStorage('userName', 'Камола');
  const [theme, setTheme] = useLocalStorage('appTheme', 'light');

  return (
    <div className="local-storage-demo">
      <h3>💾 useLocalStorage Demo</h3>
      
      <div className="form-group">
        <label>Имя пользователя:</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Введите имя"
        />
        <small>Сохраняется в localStorage</small>
      </div>

      <div className="form-group">
        <label>Тема:</label>
        <select value={theme} onChange={(e) => setTheme(e.target.value)}>
          <option value="light">🌞 Светлая</option>
          <option value="dark">🌙 Тёмная</option>
          <option value="green">🎋 Зелёная</option>
        </select>
        <small>Текущая тема: {theme}</small>
      </div>

      <div className="storage-info">
        <p><strong>Текущие значения:</strong></p>
        <p>Имя: {name}</p>
        <p>Тема: {theme}</p>
      </div>
    </div>
  );
};

// 7.2. Кастомный хук useFetch
const useFetch = (url) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Ошибка загрузки данных');
        }
        
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url]);

  return { data, loading, error };
};

// Компонент с useFetch
const FetchDemo = () => {
  const [postId, setPostId] = useState(1);
  const { data: post, loading, error } = useFetch(
    `https://jsonplaceholder.typicode.com/posts/${postId}`
  );

  return (
    <div className="fetch-demo">
      <h3>🌐 useFetch Demo</h3>
      
      <div className="post-controls">
        <label>
          ID поста (1-100):
          <input
            type="number"
            min="1"
            max="100"
            value={postId}
            onChange={(e) => setPostId(parseInt(e.target.value))}
          />
        </label>
      </div>

      {loading && <div className="loading">🔄 Загрузка...</div>}
      {error && <div className="error">❌ {error}</div>}
      
      {post && !loading && (
        <div className="post-data">
          <h4>{post.title}</h4>
          <p>{post.body}</p>
          <div className="post-meta">
            <small>Post ID: {post.id} | User ID: {post.userId}</small>
          </div>
        </div>
      )}
    </div>
  );
};

// 7.3. Компонент переключения темы с useContext
const ThemeToggle = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <div className="theme-toggle">
      <h3>🎨 Переключение темы</h3>
      <div className={`theme-preview ${theme}`}>
        <p>Текущая тема: <strong>{theme}</strong></p>
        <p>Это демонстрация использования React Context</p>
      </div>
      <button className="btn btn-primary" onClick={toggleTheme}>
        {theme === 'light' ? '🌙 Тёмная тема' : '🌞 Светлая тема'}
      </button>
    </div>
  );
};

// Провайдер темы
const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Основной компонент
const HooksComponents = () => {
  return (
    <ThemeProvider>
      <div className="hooks-components">
        <div className="components-grid">
          <div className="component-card">
            <CounterWithHooks />
          </div>
          
          <div className="component-card">
            <UserProfile />
          </div>
          
          <div className="component-card">
            <EffectDemo />
          </div>
          
          <div className="component-card">
            <LocalStorageDemo />
          </div>
          
          <div className="component-card">
            <FetchDemo />
          </div>
          
          <div className="component-card">
            <ThemeToggle />
          </div>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default HooksComponents;
import React, { useState } from 'react';
import './BasicComponents.css';

// 1.1. Компонент WelcomeMessage
const WelcomeMessage = ({ name, age }) => {
  return (
    <div className="welcome-message">
      <h3>👋 Добро пожаловать, {name}!</h3>
      <p>Возраст: {age} лет</p>
    </div>
  );
};

// 1.2. Компонент UserCard
const UserCard = ({ user }) => {
  return (
    <div className={`user-card ${user.isOnline ? 'online' : 'offline'}`}>
      <div className="user-avatar">
        <img src={user.avatar} alt={user.name} />
        <span className={`status ${user.isOnline ? 'online' : 'offline'}`}></span>
      </div>
      <div className="user-info">
        <h4>{user.name}</h4>
        <p>{user.email}</p>
        <span className="status-text">
          {user.isOnline ? '🟢 В сети' : '🔴 Не в сети'}
        </span>
      </div>
    </div>
  );
};

// 1.3. Компонент Button
const Button = ({ variant = 'primary', size = 'medium', onClick, children }) => {
  return (
    <button 
      className={`btn btn-${variant} btn-${size}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

// 2.1. Компонент Card
const Card = ({ title, children }) => {
  return (
    <div className="card">
      {title && <h3 className="card-title">{title}</h3>}
      <div className="card-content">
        {children}
      </div>
    </div>
  );
};

// 2.2. Компонент Toggle
const Toggle = ({ children }) => {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <div className="toggle">
      <Button onClick={() => setIsVisible(!isVisible)}>
        {isVisible ? '👆 Скрыть' : '👇 Показать'}
      </Button>
      {isVisible && (
        <div className="toggle-content">
          {children}
        </div>
      )}
    </div>
  );
};

// 2.3. Компонент ConditionalMessage
const ConditionalMessage = ({ status }) => {
  const messages = {
    success: { text: '✅ Операция выполнена успешно!', color: 'success' },
    error: { text: '❌ Произошла ошибка!', color: 'error' },
    warning: { text: '⚠️ Внимание! Проверьте данные.', color: 'warning' }
  };

  const message = messages[status] || { text: 'ℹ️ Информационное сообщение', color: 'info' };

  return (
    <div className={`message message-${message.color}`}>
      {message.text}
    </div>
  );
};

// Основной компонент
const BasicComponents = () => {
  const user = {
    name: 'Камола Юсупова',
    email: 'kamola@gmail.com',
    avatar: 'https://avatars.mds.yandex.net/get-shedevrum/12423216/d9f18291e92711ee95211e2d0b427d15/orig',
    isOnline: true
  };

  return (
    <div className="basic-components">
      <div className="components-grid">
        {/* WelcomeMessage */}
        <Card title="Приветственное сообщение">
          <WelcomeMessage name="Камола" age={17} />
        </Card>

        {/* UserCard */}
        <Card title="Карточка пользователя">
          <UserCard user={user} />
        </Card>

        {/* Buttons */}
        <Card title="Кнопки">
          <div className="buttons-demo">
            <Button variant="primary">Основная кнопка</Button>
            <Button variant="secondary">Вторичная кнопка</Button>
            <Button size="small">Маленькая</Button>
            <Button size="large">Большая</Button>
          </div>
        </Card>

        {/* Toggle */}
        <Card title="Переключатель">
          <Toggle>
            <p>Это скрытый контент! Он появляется при нажатии на кнопку.</p>
          </Toggle>
        </Card>

        {/* ConditionalMessage */}
        <Card title="Условные сообщения">
          <ConditionalMessage status="success" />
          <ConditionalMessage status="error" />
          <ConditionalMessage status="warning" />
        </Card>
      </div>
    </div>
  );
};

export default BasicComponents;
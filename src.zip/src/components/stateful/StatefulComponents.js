import React, { Component } from 'react';
import './StatefulComponents.css';

// 3.1. Классовый компонент Counter
class Counter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
  }

  increment = () => {
    this.setState({ count: this.state.count + 1 });
  };

  decrement = () => {
    this.setState({ count: this.state.count - 1 });
  };

  reset = () => {
    this.setState({ count: 0 });
  };

  render() {
    return (
      <div className="counter">
        <h3>Счётчик: <span className="count-value">{this.state.count}</span></h3>
        <div className="counter-buttons">
          <button className="btn btn-primary" onClick={this.decrement}>
            ➖ Уменьшить
          </button>
          <button className="btn btn-secondary" onClick={this.reset}>
            🔄 Сбросить
          </button>
          <button className="btn btn-primary" onClick={this.increment}>
            ➕ Увеличить
          </button>
        </div>
      </div>
    );
  }
}

// 3.2. Классовый компонент LoginForm
class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      errors: {}
    };
  }

  validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const errors = {};

    if (!this.state.email) {
      errors.email = 'Email обязателен';
    } else if (!this.validateEmail(this.state.email)) {
      errors.email = 'Некорректный email';
    }

    if (!this.state.password) {
      errors.password = 'Пароль обязателен';
    } else if (this.state.password.length < 6) {
      errors.password = 'Пароль должен быть не менее 6 символов';
    }

    this.setState({ errors });

    if (Object.keys(errors).length === 0) {
      alert('Форма успешно отправлена!');
      this.setState({ email: '', password: '', errors: {} });
    }
  };

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
      errors: {
        ...this.state.errors,
        [e.target.name]: ''
      }
    });
  };

  render() {
    return (
      <form className="login-form" onSubmit={this.handleSubmit}>
        <h3>Форма входа</h3>
        
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={this.state.email}
            onChange={this.handleChange}
            className={this.state.errors.email ? 'error' : ''}
            placeholder="Введите ваш email"
          />
          {this.state.errors.email && (
            <span className="error-message">{this.state.errors.email}</span>
          )}
        </div>

        <div className="form-group">
          <label>Пароль:</label>
          <input
            type="password"
            name="password"
            value={this.state.password}
            onChange={this.handleChange}
            className={this.state.errors.password ? 'error' : ''}
            placeholder="Введите пароль"
          />
          {this.state.errors.password && (
            <span className="error-message">{this.state.errors.password}</span>
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          🔐 Войти
        </button>
      </form>
    );
  }
}

// 3.3. Классовый компонент ColorPicker
class ColorPicker extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedColor: '#4caf50',
      colors: ['#4caf50', '#2196f3', '#ff9800', '#f44336', '#9c27b0', '#607d8b']
    };
  }

  handleColorSelect = (color) => {
    this.setState({ selectedColor: color });
  };

  render() {
    return (
      <div className="color-picker">
        <h3>Выбор цвета</h3>
        <div 
          className="color-preview"
          style={{ backgroundColor: this.state.selectedColor }}
        >
          Выбранный цвет: {this.state.selectedColor}
        </div>
        <div className="color-options">
          {this.state.colors.map((color, index) => (
            <div
              key={index}
              className={`color-option ${this.state.selectedColor === color ? 'selected' : ''}`}
              style={{ backgroundColor: color }}
              onClick={() => this.handleColorSelect(color)}
            />
          ))}
        </div>
      </div>
    );
  }
}

// 4.1. Классовый компонент TodoList
class TodoList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [],
      newTodo: ''
    };
  }

  addTodo = () => {
    if (this.state.newTodo.trim()) {
      this.setState({
        todos: [...this.state.todos, {
          id: Date.now(),
          text: this.state.newTodo,
          completed: false
        }],
        newTodo: ''
      });
    }
  };

  deleteTodo = (id) => {
    this.setState({
      todos: this.state.todos.filter(todo => todo.id !== id)
    });
  };

  toggleTodo = (id) => {
    this.setState({
      todos: this.state.todos.map(todo =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    });
  };

  handleInputChange = (e) => {
    this.setState({ newTodo: e.target.value });
  };

  handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      this.addTodo();
    }
  };

  render() {
    return (
      <div className="todo-list">
        <h3>📝 Список задач</h3>
        
        <div className="todo-input">
          <input
            type="text"
            value={this.state.newTodo}
            onChange={this.handleInputChange}
            onKeyPress={this.handleKeyPress}
            placeholder="Введите новую задачу..."
          />
          <button className="btn btn-primary" onClick={this.addTodo}>
            ➕ Добавить
          </button>
        </div>

        <div className="todos">
          {this.state.todos.map(todo => (
            <div key={todo.id} className={`todo-item ${todo.completed ? 'completed' : ''}`}>
              <span 
                className="todo-text"
                onClick={() => this.toggleTodo(todo.id)}
              >
                {todo.text}
              </span>
              <button 
                className="btn btn-secondary"
                onClick={() => this.deleteTodo(todo.id)}
              >
                🗑️ Удалить
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

// Основной компонент
class StatefulComponents extends Component {
  render() {
    return (
      <div className="stateful-components">
        <div className="components-grid">
          <div className="component-card">
            <Counter />
          </div>
          
          <div className="component-card">
            <LoginForm />
          </div>
          
          <div className="component-card">
            <ColorPicker />
          </div>
          
          <div className="component-card">
            <TodoList />
          </div>
        </div>
      </div>
    );
  }
}

export default StatefulComponents;
import React, { useState } from 'react';
import './ComponentTests.css';

const ComponentTests = () => {
  const [testResults, setTestResults] = useState({
    basic: false,
    stateful: false,
    lifecycle: false,
    hooks: false,
    integration: false
  });

  const [testLog, setTestLog] = useState([]);
  const [activeTestTab, setActiveTestTab] = useState('controls');

  const addLog = (message, type = 'info') => {
    setTestLog(prev => [...prev, { 
      message, 
      type, 
      timestamp: new Date().toLocaleTimeString(),
      id: Date.now() + Math.random()
    }]);
  };

  const runBasicTests = () => {
    addLog('🧪 Запуск тестов базовых компонентов...', 'info');
    
    setTimeout(() => {
      const passed = Math.random() > 0.2;
      setTestResults(prev => ({ ...prev, basic: passed }));
      
      if (passed) {
        addLog('✅ Базовые компоненты: Все тесты пройдены', 'success');
        addLog('✓ WelcomeMessage рендерится корректно', 'success');
        addLog('✓ UserCard отображает данные пользователя', 'success');
        addLog('✓ Button поддерживает разные варианты', 'success');
      } else {
        addLog('❌ Базовые компоненты: Обнаружены ошибки в рендеринге', 'error');
        addLog('✗ Ошибка в передаче props в WelcomeMessage', 'error');
      }
    }, 1000);
  };

  const runAllTests = () => {
    addLog('🚀 Запуск всех тестов...', 'warning');
    setTestLog([]);
    setTestResults({
      basic: false,
      stateful: false,
      lifecycle: false,
      hooks: false,
      integration: false
    });

    // Симуляция запуска всех тестов
    runBasicTests();
    setTimeout(() => {
      setTestResults(prev => ({ ...prev, stateful: Math.random() > 0.1 }));
      addLog('✅ Компоненты с состоянием: Управление состоянием работает корректно', 'success');
    }, 1500);
    
    setTimeout(() => {
      setTestResults(prev => ({ ...prev, lifecycle: Math.random() > 0.15 }));
      addLog('✅ Жизненный цикл: Методы выполняются корректно', 'success');
    }, 2500);
    
    setTimeout(() => {
      setTestResults(prev => ({ ...prev, hooks: Math.random() > 0.25 }));
      addLog('✅ Хуки: useState и useEffect работают правильно', 'success');
    }, 3500);
    
    setTimeout(() => {
      setTestResults(prev => ({ ...prev, integration: Math.random() > 0.3 }));
      addLog('✅ Интеграционные тесты: Все компоненты работают вместе', 'success');
      addLog('🎉 Все тесты завершены!', 'success');
    }, 4500);
  };

  const clearTests = () => {
    setTestResults({
      basic: false,
      stateful: false,
      lifecycle: false,
      hooks: false,
      integration: false
    });
    setTestLog([]);
    addLog('🧹 Результаты тестов очищены', 'info');
  };

  const passedTests = Object.values(testResults).filter(Boolean).length;
  const totalTests = Object.values(testResults).length;
  const progress = (passedTests / totalTests) * 100;

  const testTabs = [
    { id: 'controls', name: '🎮 Управление' },
    { id: 'results', name: '📊 Результаты' },
    { id: 'log', name: '📝 Лог' },
    { id: 'summary', name: '📋 Сводка' }
  ];

  return (
    <div className="component-tests">
      <div className="tests-navigation">
        {testTabs.map(tab => (
          <button
            key={tab.id}
            className={`test-tab ${activeTestTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTestTab(tab.id)}
          >
            {tab.name}
          </button>
        ))}
      </div>

      <div className="tests-content">
        {activeTestTab === 'controls' && (
          <div className="tab-panel">
            <div className="tests-header">
              <h3>🎮 Управление тестированием</h3>
              <p>Запустите тесты для проверки компонентов</p>
            </div>

            <div className="tests-controls">
              <button className="btn btn-primary large" onClick={runAllTests}>
                🚀 Запустить все тесты
              </button>
              <button className="btn btn-secondary" onClick={clearTests}>
                🧹 Очистить результаты
              </button>
            </div>

            <div className="tests-progress">
              <div className="progress-info">
                <span>Прогресс тестирования:</span>
                <span>{passedTests} / {totalTests}</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
          </div>
        )}

        {activeTestTab === 'results' && (
          <div className="tab-panel">
            <div className="tests-header">
              <h3>📊 Результаты тестирования</h3>
              <p>Обзор пройденных и непройденных тестов</p>
            </div>

            <div className="results-grid">
              <div className={`test-result ${testResults.basic ? 'passed' : 'failed'}`}>
                <div className="test-icon">
                  {testResults.basic ? '✅' : '❌'}
                </div>
                <div className="test-info">
                  <h4>Базовые компоненты</h4>
                  <p>Проверка функциональных компонентов и props</p>
                </div>
                <div className="test-status">
                  {testResults.basic ? 'Пройдено' : 'Не пройдено'}
                </div>
              </div>

              <div className={`test-result ${testResults.stateful ? 'passed' : 'failed'}`}>
                <div className="test-icon">
                  {testResults.stateful ? '✅' : '❌'}
                </div>
                <div className="test-info">
                  <h4>Компоненты с состоянием</h4>
                  <p>Проверка управления состоянием и событий</p>
                </div>
                <div className="test-status">
                  {testResults.stateful ? 'Пройдено' : 'Не пройдено'}
                </div>
              </div>

              <div className={`test-result ${testResults.lifecycle ? 'passed' : 'failed'}`}>
                <div className="test-icon">
                  {testResults.lifecycle ? '✅' : '❌'}
                </div>
                <div className="test-info">
                  <h4>Жизненный цикл</h4>
                  <p>Проверка методов жизненного цикла</p>
                </div>
                <div className="test-status">
                  {testResults.lifecycle ? 'Пройдено' : 'Не пройдено'}
                </div>
              </div>

              <div className={`test-result ${testResults.hooks ? 'passed' : 'failed'}`}>
                <div className="test-icon">
                  {testResults.hooks ? '✅' : '❌'}
                </div>
                <div className="test-info">
                  <h4>React Hooks</h4>
                  <p>Проверка хуков и кастомных хуков</p>
                </div>
                <div className="test-status">
                  {testResults.hooks ? 'Пройдено' : 'Не пройдено'}
                </div>
              </div>

              <div className={`test-result ${testResults.integration ? 'passed' : 'failed'}`}>
                <div className="test-icon">
                  {testResults.integration ? '✅' : '❌'}
                </div>
                <div className="test-info">
                  <h4>Интеграционные тесты</h4>
                  <p>Проверка взаимодействия компонентов</p>
                </div>
                <div className="test-status">
                  {testResults.integration ? 'Пройдено' : 'Не пройдено'}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTestTab === 'log' && (
          <div className="tab-panel">
            <div className="tests-header">
              <h3>📝 Лог выполнения тестов</h3>
              <p>Детальная информация о процессе тестирования</p>
            </div>

            <div className="log-container">
              {testLog.length === 0 ? (
                <div className="empty-log">
                  <div className="empty-icon">📄</div>
                  <p>Лог пуст. Запустите тесты для просмотра результатов.</p>
                </div>
              ) : (
                testLog.map((entry) => (
                  <div key={entry.id} className={`log-entry log-${entry.type}`}>
                    <span className="log-time">[{entry.timestamp}]</span>
                    <span className="log-message">{entry.message}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTestTab === 'summary' && (
          <div className="tab-panel">
            <div className="tests-header">
              <h3>📋 Сводка по компонентам</h3>
              <p>Обзор всех реализованных компонентов</p>
            </div>

            <div className="summary-grid">
              <div className="summary-category">
                <h4>📋 Базовые компоненты</h4>
                <div className="components-list">
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>WelcomeMessage - приветствие с props</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>UserCard - карточка пользователя</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>Button - переиспользуемая кнопка</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>Card - контейнер с заголовком</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>Toggle - скрытие/показ контента</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>ConditionalMessage - условный рендеринг</span>
                  </div>
                </div>
              </div>

              <div className="summary-category">
                <h4>⚡ Компоненты с состоянием</h4>
                <div className="components-list">
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>Counter - счётчик на классах</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>LoginForm - форма с валидацией</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>ColorPicker - выбор цвета</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>TodoList - список задач</span>
                  </div>
                </div>
              </div>

              <div className="summary-category">
                <h4>🔄 Жизненный цикл</h4>
                <div className="components-list">
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>Timer - секундомер</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>WindowSizeTracker - отслеживание размера</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>DataFetcher - загрузка данных</span>
                  </div>
                </div>
              </div>

              <div className="summary-category">
                <h4>🎣 React Hooks</h4>
                <div className="components-list">
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>CounterWithHooks - счётчик на хуках</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>UserProfile - редактирование профиля</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>EffectDemo - демо useEffect</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>useLocalStorage - кастомный хук</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>useFetch - кастомный хук</span>
                  </div>
                  <div className="component-item success">
                    <span className="component-icon">✅</span>
                    <span>ThemeToggle - контекст и useContext</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ComponentTests;
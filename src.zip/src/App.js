import React, { useState } from 'react';
import './App.css';
import BasicComponents from './components/basic/BasicComponents';
import StatefulComponents from './components/stateful/StatefulComponents';
import LifecycleComponents from './components/lifecycle/LifecycleComponents';
import HooksComponents from './components/hooks/HooksComponents';
import ComponentTests from './components/ComponentTests';

function App() {
  const [activeSection, setActiveSection] = useState('basic');

  const sections = [
    { id: 'basic', name: '📋 Базовые', component: <BasicComponents /> },
    { id: 'stateful', name: '⚡ Состояние', component: <StatefulComponents /> },
    { id: 'lifecycle', name: '🔄 Жизненный цикл', component: <LifecycleComponents /> },
    { id: 'hooks', name: '🎣 Hooks', component: <HooksComponents /> },
    { id: 'tests', name: '🧪 Тесты', component: <ComponentTests /> }
  ];

  const activeComponent = sections.find(section => section.id === activeSection)?.component;

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <h1>React Components Practice</h1>
          <div className="student-info">
            <p><strong>Студент:</strong> Юсупова Камола</p>
            <p><strong>Группа:</strong> 319</p>
            <p><strong>Почта:</strong> kamola@gmail.com</p>
          </div>
        </div>
      </header>
      
      <nav className="app-navigation">
        <div className="nav-container">
          {sections.map(section => (
            <button
              key={section.id}
              className={`nav-button ${activeSection === section.id ? 'active' : ''}`}
              onClick={() => setActiveSection(section.id)}
            >
              {section.name}
            </button>
          ))}
        </div>
      </nav>

      <main className="app-main">
        <section className="component-section">
          <div className="section-header">
            <h2>{sections.find(s => s.id === activeSection)?.name} компоненты</h2>
            <div className="section-indicator">
              {sections.findIndex(s => s.id === activeSection) + 1} из {sections.length}
            </div>
          </div>
          {activeComponent}
        </section>
      </main>

      <footer className="app-footer">
        <div className="footer-content">
          <p>Практическая работа №15 выполнена Юсуповой Камолой</p>
        </div>
      </footer>
    </div>
  );
}

export default App;

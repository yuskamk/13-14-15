// === FETCH API - ОСНОВНЫЕ ЗАДАНИЯ ===

// Базовый URL для JSONPlaceholder API
const API_BASE_URL = 'https://jsonplaceholder.typicode.com';

// Вспомогательные функции
function displayOutput(elementId, content, className = '') {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = `<div class="${className}">${content}</div>`;
    }
}

function clearOutput(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '';
    }
}

function formatJSON(data) {
    return JSON.stringify(data, null, 2);
}

// ЗАДАНИЕ 1: Базовые GET запросы

// 1.1. Создайте функцию fetchGetRequest, которая выполняет простой GET запрос
async function fetchGetRequest() {
    try {
        displayOutput('get-output', '<span class="loading"></span> Загрузка...', 'warning');
        
        const response = await fetch(`${API_BASE_URL}/posts/1`);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const data = await response.json();
        displayOutput('get-output', `
            <strong>✅ Успешный GET запрос:</strong>
            <pre>${formatJSON(data)}</pre>
        `, 'success');
        
    } catch (error) {
        displayOutput('get-output', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 1.2. Создайте функцию fetchJsonData, которая получает и отображает JSON данные
async function fetchJsonData() {
    try {
        displayOutput('get-data', '<span class="loading"></span> Загрузка пользователей...', 'warning');
        
        const response = await fetch(`${API_BASE_URL}/users`);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const users = await response.json();
        
        const usersHTML = users.map(user => `
            <div class="user-card">
                <h3>👤 ${user.name}</h3>
                <p><strong>📧 Email:</strong> ${user.email}</p>
                <p><strong>📞 Телефон:</strong> ${user.phone}</p>
                <p><strong>🏢 Компания:</strong> ${user.company.name}</p>
                <p><strong>🌐 Сайт:</strong> ${user.website}</p>
            </div>
        `).join('');
        
        displayOutput('get-data', `
            <h3>📊 Пользователи (${users.length})</h3>
            ${usersHTML}
        `, 'success');
        
    } catch (error) {
        displayOutput('get-data', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 1.3. Создайте функцию fetchWithError, которая тестирует обработку ошибок
async function fetchWithError() {
    try {
        displayOutput('get-output', '<span class="loading"></span> Попытка запроса к несуществующему URL...', 'warning');
        
        // Запрос к несуществующему endpoint
        const response = await fetch(`${API_BASE_URL}/nonexistent-endpoint`);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        displayOutput('get-output', `<pre>${formatJSON(data)}</pre>`, 'success');
        
    } catch (error) {
        displayOutput('get-output', `
            <strong>❌ Обработка ошибок:</strong><br>
            <strong>Тип ошибки:</strong> ${error.name}<br>
            <strong>Сообщение:</strong> ${error.message}<br>
            <strong>Разница между сетевыми и HTTP ошибками:</strong><br>
            - Сетевые ошибки: проблемы с подключением, DNS, CORS<br>
            - HTTP ошибки: сервер ответил, но с ошибкой (404, 500, etc.)
        `, 'error');
    }
}

// 1.4. Создайте функцию setupGetRequests, которая настраивает обработчики
function setupGetRequests() {
    document.getElementById('fetch-get').addEventListener('click', fetchGetRequest);
    document.getElementById('fetch-json').addEventListener('click', fetchJsonData);
    document.getElementById('fetch-error').addEventListener('click', fetchWithError);
}

// ЗАДАНИЕ 2: POST, PUT, DELETE запросы

// 2.1. Создайте функцию fetchPostRequest, которая отправляет POST запрос
async function fetchPostRequest() {
    try {
        const newPost = {
            title: 'Новый пост',
            body: 'Содержание нового поста',
            userId: 1
        };
        
        const response = await fetch(`${API_BASE_URL}/posts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newPost)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const createdPost = await response.json();
        displayOutput('crud-output', `
            <strong>✅ POST запрос выполнен успешно:</strong>
            <pre>${formatJSON(createdPost)}</pre>
            <p><strong>ID созданного поста:</strong> ${createdPost.id}</p>
        `, 'success');
        
    } catch (error) {
        displayOutput('crud-output', `
            <strong>❌ Ошибка при POST запросе:</strong> ${error.message}
        `, 'error');
    }
}

// 2.2. Создайте функцию fetchPutRequest, которая отправляет PUT запрос
async function fetchPutRequest() {
    try {
        const updatedPost = {
            id: 1,
            title: 'Обновленный пост',
            body: 'Обновленное содержание поста',
            userId: 1
        };
        
        const response = await fetch(`${API_BASE_URL}/posts/1`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedPost)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const result = await response.json();
        displayOutput('crud-output', `
            <strong>✅ PUT запрос выполнен успешно:</strong>
            <pre>${formatJSON(result)}</pre>
            <p><strong>PUT vs PATCH:</strong> PUT заменяет весь ресурс, PATCH - только указанные поля</p>
        `, 'success');
        
    } catch (error) {
        displayOutput('crud-output', `
            <strong>❌ Ошибка при PUT запросе:</strong> ${error.message}
        `, 'error');
    }
}

// 2.3. Создайте функцию fetchPatchRequest, которая отправляет PATCH запрос
async function fetchPatchRequest() {
    try {
        const partialUpdate = {
            title: 'Частично обновленный заголовок'
        };
        
        const response = await fetch(`${API_BASE_URL}/posts/1`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(partialUpdate)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const result = await response.json();
        displayOutput('crud-output', `
            <strong>✅ PATCH запрос выполнен успешно:</strong>
            <pre>${formatJSON(result)}</pre>
            <p><strong>Разница PUT vs PATCH:</strong><br>
            - PUT: заменяет ВЕСЬ ресурс<br>
            - PATCH: обновляет только указанные поля</p>
        `, 'success');
        
    } catch (error) {
        displayOutput('crud-output', `
            <strong>❌ Ошибка при PATCH запросе:</strong> ${error.message}
        `, 'error');
    }
}

// 2.4. Создайте функцию fetchDeleteRequest, которая отправляет DELETE запрос
async function fetchDeleteRequest() {
    try {
        const response = await fetch(`${API_BASE_URL}/posts/1`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        // DELETE запрос обычно возвращает пустой объект или статус 200
        displayOutput('crud-output', `
            <strong>✅ DELETE запрос выполнен успешно!</strong><br>
            <strong>Статус:</strong> ${response.status}<br>
            <strong>Ресурс с ID 1 был удален</strong>
        `, 'success');
        
    } catch (error) {
        displayOutput('crud-output', `
            <strong>❌ Ошибка при DELETE запросе:</strong> ${error.message}
        `, 'error');
    }
}

// 2.5. Создайте функцию setupCrudRequests, которая настраивает обработчики
function setupCrudRequests() {
    document.getElementById('fetch-post').addEventListener('click', fetchPostRequest);
    document.getElementById('fetch-put').addEventListener('click', fetchPutRequest);
    document.getElementById('fetch-patch').addEventListener('click', fetchPatchRequest);
    document.getElementById('fetch-delete').addEventListener('click', fetchDeleteRequest);
}

// ЗАДАНИЕ 3: Заголовки и параметры

// 3.1. Создайте функцию fetchWithHeaders, которая отправляет запрос с кастомными заголовками
async function fetchWithHeaders() {
    try {
        const response = await fetch(`${API_BASE_URL}/posts`, {
            method: 'GET',
            headers: {
                'X-Custom-Header': 'CustomValue123',
                'Authorization': 'Bearer fake-jwt-token',
                'X-Request-ID': '12345',
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const data = await response.json();
        
        displayOutput('headers-output', `
            <strong>✅ Запрос с кастомными заголовками выполнен:</strong>
            <p><strong>Отправленные заголовки:</strong></p>
            <ul class="header-list">
                <li>X-Custom-Header: CustomValue123</li>
                <li>Authorization: Bearer fake-jwt-token</li>
                <li>X-Request-ID: 12345</li>
                <li>Content-Type: application/json</li>
            </ul>
            <p><strong>Получено постов:</strong> ${data.length}</p>
        `, 'success');
        
    } catch (error) {
        displayOutput('headers-output', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 3.2. Создайте функцию fetchWithAuth, которая имитирует авторизацию
async function fetchWithAuth() {
    try {
        // Basic Auth пример
        const username = 'user';
        const password = 'pass';
        const basicAuth = btoa(`${username}:${password}`);
        
        const response = await fetch(`${API_BASE_URL}/posts`, {
            headers: {
                'Authorization': `Basic ${basicAuth}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const data = await response.json();
        
        displayOutput('headers-output', `
            <strong>✅ Авторизация выполнена:</strong>
            <p><strong>Тип авторизации:</strong> Basic Auth</p>
            <p><strong>Заголовок:</strong> Authorization: Basic ${basicAuth}</p>
            <p><strong>Способы авторизации:</strong></p>
            <ul class="header-list">
                <li><strong>Basic Auth:</strong> Base64(login:password)</li>
                <li><strong>Bearer Token:</strong> Authorization: Bearer {token}</li>
                <li><strong>API Key:</strong> X-API-Key: {key}</li>
                <li><strong>OAuth2:</strong> Authorization: Bearer {access_token}</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('headers-output', `
            <strong>❌ Ошибка авторизации:</strong> ${error.message}
        `, 'error');
    }
}

// 3.3. Создайте функцию fetchWithParams, которая добавляет параметры к URL
async function fetchWithParams() {
    try {
        // Способ 1: URLSearchParams
        const params = new URLSearchParams({
            '_limit': '5',
            '_sort': 'id',
            '_order': 'desc'
        });
        
        const url = `${API_BASE_URL}/posts?${params}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const data = await response.json();
        
        displayOutput('headers-output', `
            <strong>✅ Запрос с параметрами выполнен:</strong>
            <p><strong>URL:</strong> ${url}</p>
            <p><strong>Параметры:</strong></p>
            <ul class="header-list">
                <li>_limit=5 (ограничение количества)</li>
                <li>_sort=id (сортировка по ID)</li>
                <li>_order=desc (порядок убывания)</li>
            </ul>
            <p><strong>Получено постов:</strong> ${data.length}</p>
            <pre>${formatJSON(data)}</pre>
        `, 'success');
        
    } catch (error) {
        displayOutput('headers-output', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 3.4. Создайте функцию fetchWithTimeout, которая реализует таймаут для запроса
async function fetchWithTimeout() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3000);
        
        displayOutput('headers-output', '<span class="loading"></span> Запрос с таймаутом 3 секунды...', 'warning');
        
        // Имитируем медленный запрос
        const response = await fetch(`${API_BASE_URL}/posts?_delay=5000`, {
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const data = await response.json();
        displayOutput('headers-output', `
            <strong>✅ Запрос завершен до таймаута:</strong>
            <p>Получено ${data.length} постов</p>
        `, 'success');
        
    } catch (error) {
        if (error.name === 'AbortError') {
            displayOutput('headers-output', `
                <strong>⏰ Таймаут запроса:</strong> Запрос был отменен через 3 секунды
                <p><strong>AbortController</strong> позволяет отменять fetch запросы</p>
            `, 'error');
        } else {
            displayOutput('headers-output', `
                <strong>❌ Ошибка:</strong> ${error.message}
            `, 'error');
        }
    }
}

// 3.5. Создайте функцию setupHeadersAndParams, которая настраивает обработчики
function setupHeadersAndParams() {
    document.getElementById('fetch-headers').addEventListener('click', fetchWithHeaders);
    document.getElementById('fetch-auth').addEventListener('click', fetchWithAuth);
    document.getElementById('fetch-params').addEventListener('click', fetchWithParams);
    document.getElementById('fetch-timeout').addEventListener('click', fetchWithTimeout);
}

// ЗАДАНИЕ 4: Обработка ответов

// 4.1. Создайте функцию fetchAndCheckStatus, которая проверяет статус ответа
async function fetchAndCheckStatus() {
    try {
        const response = await fetch(`${API_BASE_URL}/posts/9999`); // Несуществующий пост
        
        // Проверяем статус ответа
        if (!response.ok) {
            if (response.status === 404) {
                throw new Error('Ресурс не найден (404)');
            } else if (response.status >= 500) {
                throw new Error('Ошибка сервера (5xx)');
            } else {
                throw new Error(`HTTP ошибка: ${response.status}`);
            }
        }
        
        const data = await response.json();
        displayOutput('response-output', `
            <strong>✅ Статус проверен:</strong> ${response.status}
            <pre>${formatJSON(data)}</pre>
        `, 'success');
        
    } catch (error) {
        displayOutput('response-output', `
            <strong>🔍 Проверка статуса:</strong><br>
            <strong>Ошибка:</strong> ${error.message}<br>
            <strong>response.ok:</strong> false<br>
            <strong>Обработка HTTP статусов:</strong><br>
            - 200-299: Успех<br>
            - 404: Не найдено<br>
            - 500: Ошибка сервера
        `, 'error');
    }
}

// 4.2. Создайте функцию fetchAndReadHeaders, которая читает заголовки ответа
async function fetchAndReadHeaders() {
    try {
        const response = await fetch(`${API_BASE_URL}/posts/1`);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        // Получаем все заголовки
        const headers = [];
        response.headers.forEach((value, name) => {
            headers.push({ name, value });
        });
        
        const headersHTML = headers.map(header => `
            <li><strong>${header.name}:</strong> ${header.value}</li>
        `).join('');
        
        displayOutput('response-output', `
            <strong>📋 Заголовки ответа:</strong>
            <ul class="header-list">
                ${headersHTML}
            </ul>
            <p><strong>Важные заголовки:</strong></p>
            <ul class="header-list">
                <li><strong>Content-Type:</strong> тип содержимого</li>
                <li><strong>Content-Length:</strong> размер содержимого</li>
                <li><strong>Date:</strong> дата ответа</li>
                <li><strong>Cache-Control:</strong> управление кэшированием</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('response-output', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 4.3. Создайте функцию fetchBlobData, которая работает с бинарными данными
async function fetchBlobData() {
    try {
        displayOutput('response-output', '<span class="loading"></span> Загрузка изображения...', 'warning');
        
        const response = await fetch('https://picsum.photos/200/300');
        
        if (!response.ok) {
            throw new Error(`Ошибка загрузки изображения: ${response.status}`);
        }
        
        const blob = await response.blob();
        const imageUrl = URL.createObjectURL(blob);
        
        displayOutput('response-output', `
            <strong>✅ BLOB данные загружены:</strong>
            <div class="image-container">
                <img src="${imageUrl}" alt="Загруженное изображение">
            </div>
            <p><strong>Информация о BLOB:</strong></p>
            <ul class="header-list">
                <li><strong>Размер:</strong> ${blob.size} байт</li>
                <li><strong>Тип:</strong> ${blob.type}</li>
                <li><strong>URL создан через:</strong> URL.createObjectURL(blob)</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('response-output', `
            <strong>❌ Ошибка загрузки BLOB:</strong> ${error.message}
        `, 'error');
    }
}

// 4.4. Создайте функцию fetchWithFormData, которая отправляет FormData
async function fetchWithFormData() {
    try {
        // Создаем FormData
        const formData = new FormData();
        formData.append('title', 'Заголовок из FormData');
        formData.append('body', 'Содержание из FormData');
        formData.append('userId', '1');
        
        const response = await fetch(`${API_BASE_URL}/posts`, {
            method: 'POST',
            body: formData
            // Заголовок Content-Type устанавливается автоматически как multipart/form-data
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const result = await response.json();
        
        displayOutput('response-output', `
            <strong>✅ FormData отправлен успешно:</strong>
            <pre>${formatJSON(result)}</pre>
            <p><strong>Разница между JSON и FormData:</strong></p>
            <ul class="header-list">
                <li><strong>JSON:</strong> application/json, для структурированных данных</li>
                <li><strong>FormData:</strong> multipart/form-data, для форм и файлов</li>
                <li><strong>FormData автоматически устанавливает правильный Content-Type</strong></li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('response-output', `
            <strong>❌ Ошибка отправки FormData:</strong> ${error.message}
        `, 'error');
    }
}

// 4.5. Создайте функцию setupResponseHandling, которая настраивает обработчики
function setupResponseHandling() {
    document.getElementById('fetch-status').addEventListener('click', fetchAndCheckStatus);
    document.getElementById('fetch-response-headers').addEventListener('click', fetchAndReadHeaders);
    document.getElementById('fetch-blob').addEventListener('click', fetchBlobData);
    document.getElementById('fetch-formdata').addEventListener('click', fetchWithFormData);
}

// ЗАДАНИЕ 5: Обработка ошибок

// 5.1. Создайте функцию fetchNetworkError, которая обрабатывает сетевые ошибки
async function fetchNetworkError() {
    try {
        displayOutput('error-output', '<span class="loading"></span> Попытка подключения к несуществующему домену...', 'warning');
        
        // Запрос к несуществующему домену
        await fetch('https://nonexistent-domain-12345.example.com/api/data');
        
    } catch (error) {
        displayOutput('error-output', `
            <strong>🌐 Сетевая ошибка:</strong><br>
            <strong>Тип:</strong> ${error.name}<br>
            <strong>Сообщение:</strong> ${error.message}<br>
            <strong>Причины сетевых ошибок:</strong>
            <ul class="header-list">
                <li>Домен не существует</li>
                <li>Проблемы с DNS</li>
                <li>Нет подключения к интернету</li>
                <li>CORS ошибки</li>
                <li>Таймаут соединения</li>
            </ul>
        `, 'error');
    }
}

// 5.2. Создайте функцию fetchHttpError, которая обрабатывает HTTP ошибки
async function fetchHttpError() {
    try {
        // Запрос, который вернет 404
        const response = await fetch(`${API_BASE_URL}/nonexistent-endpoint-123`);
        
        if (!response.ok) {
            // Создаем кастомную ошибку с информацией о статусе
            const error = new Error(`HTTP Error ${response.status}`);
            error.status = response.status;
            error.statusText = response.statusText;
            throw error;
        }
        
    } catch (error) {
        displayOutput('error-output', `
            <strong>🚨 HTTP Ошибка:</strong><br>
            <strong>Статус:</strong> ${error.status || 'Неизвестно'}<br>
            <strong>Текст статуса:</strong> ${error.statusText || 'Неизвестно'}<br>
            <strong>Сообщение:</strong> ${error.message}<br>
            <strong>Разница между сетевыми и HTTP ошибками:</strong>
            <ul class="header-list">
                <li><strong>Сетевые:</strong> Не удалось выполнить запрос</li>
                <li><strong>HTTP:</strong> Запрос выполнен, но сервер вернул ошибку</li>
            </ul>
        `, 'error');
    }
}

// 5.3. Создайте функцию fetchWithAbort, которая демонстрирует отмену запроса
async function fetchWithAbort() {
    try {
        const controller = new AbortController();
        const signal = controller.signal;
        
        displayOutput('error-output', '<span class="loading"></span> Запрос выполняется... (отмена через 1 секунду)', 'warning');
        
        // Отменяем запрос через 1 секунду
        setTimeout(() => {
            controller.abort();
            displayOutput('error-output', `
                <strong>⏹️ Запрос отменен:</strong><br>
                <p>AbortController позволяет отменять fetch запросы</p>
                <p>Полезно для:</p>
                <ul class="header-list">
                    <li>Таймаутов</li>
                    <li>Отмены пользователем</li>
                    <li>Повторных запросов</li>
                </ul>
            `, 'warning');
        }, 1000);
        
        // Медленный запрос
        await fetch(`${API_BASE_URL}/posts?_delay=5000`, { signal });
        
    } catch (error) {
        if (error.name === 'AbortError') {
            // Ошибка отмены - это нормально
            return;
        }
        displayOutput('error-output', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 5.4. Создайте функцию fetchWithRetry, которая реализует повторные попытки
async function fetchWithRetry() {
    let attempts = 0;
    const maxAttempts = 3;
    
    async function attemptFetch() {
        attempts++;
        displayOutput('error-output', `<span class="loading"></span> Попытка ${attempts}/${maxAttempts}...`, 'warning');
        
        try {
            // Имитируем возможную ошибку
            if (attempts < maxAttempts) {
                throw new Error('Временная ошибка сервера');
            }
            
            const response = await fetch(`${API_BASE_URL}/posts/1`);
            
            if (!response.ok) {
                throw new Error(`HTTP ошибка: ${response.status}`);
            }
            
            const data = await response.json();
            displayOutput('error-output', `
                <strong>✅ Успех после ${attempts} попыток!</strong>
                <pre>${formatJSON(data)}</pre>
            `, 'success');
            
        } catch (error) {
            if (attempts < maxAttempts) {
                // Ждем перед следующей попыткой
                setTimeout(attemptFetch, 1000 * attempts);
            } else {
                displayOutput('error-output', `
                    <strong>❌ Все попытки завершились ошибкой:</strong><br>
                    ${error.message}<br>
                    <strong>Стратегии повторных попыток:</strong>
                    <ul class="header-list">
                        <li>Экспоненциальная задержка</li>
                        <li>Ограничение максимального количества попыток</li>
                        <li>Обработка специфических ошибок</li>
                    </ul>
                `, 'error');
            }
        }
    }
    
    attemptFetch();
}

// 5.5. Создайте функцию setupErrorHandling, которая настраивает обработчики
function setupErrorHandling() {
    document.getElementById('fetch-network-error').addEventListener('click', fetchNetworkError);
    document.getElementById('fetch-http-error').addEventListener('click', fetchHttpError);
    document.getElementById('fetch-abort').addEventListener('click', fetchWithAbort);
    document.getElementById('fetch-retry').addEventListener('click', fetchWithRetry);
}

// ЗАДАНИЕ 6: Параллельные запросы

// 6.1. Создайте функцию fetchWithPromiseAll, которая выполняет параллельные запросы
async function fetchWithPromiseAll() {
    try {
        displayOutput('parallel-output', '<span class="loading"></span> Выполнение параллельных запросов...', 'warning');
        
        const [usersResponse, postsResponse, commentsResponse] = await Promise.all([
            fetch(`${API_BASE_URL}/users`),
            fetch(`${API_BASE_URL}/posts`),
            fetch(`${API_BASE_URL}/comments`)
        ]);
        
        const [users, posts, comments] = await Promise.all([
            usersResponse.json(),
            postsResponse.json(),
            commentsResponse.json()
        ]);
        
        displayOutput('parallel-output', `
            <strong>✅ Promise.all завершен:</strong>
            <p><strong>Пользователи:</strong> ${users.length}</p>
            <p><strong>Посты:</strong> ${posts.length}</p>
            <p><strong>Комментарии:</strong> ${comments.length}</p>
            <p><strong>Преимущества Promise.all:</strong></p>
            <ul class="header-list">
                <li>Параллельное выполнение запросов</li>
                <li>Ускорение загрузки</li>
                <li>Ожидание всех результатов</li>
            </ul>
            <p><strong>Особенности:</strong> Если один запрос завершится ошибкой - все Promise.all завершится ошибкой</p>
        `, 'success');
        
    } catch (error) {
        displayOutput('parallel-output', `
            <strong>❌ Ошибка в Promise.all:</strong> ${error.message}
        `, 'error');
    }
}

// 6.2. Создайте функцию fetchWithPromiseRace, которая использует Promise.race
async function fetchWithPromiseRace() {
    try {
        displayOutput('parallel-output', '<span class="loading"></span> Ожидание первого завершенного запроса...', 'warning');
        
        const fastApi = fetch(`${API_BASE_URL}/posts/1`); // Быстрый запрос
        const slowApi = fetch(`${API_BASE_URL}/posts?_delay=3000`); // Медленный запрос
        
        const winner = await Promise.race([fastApi, slowApi]);
        
        const data = await winner.json();
        
        displayOutput('parallel-output', `
            <strong>🏁 Promise.race завершен:</strong>
            <p>Победил самый быстрый запрос!</p>
            <pre>${formatJSON(data)}</pre>
            <p><strong>Использование Promise.race:</strong></p>
            <ul class="header-list">
                <li>Таймауты запросов</li>
                <li>Выбор самого быстрого источника</li>
                <li>Отмена медленных операций</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('parallel-output', `
            <strong>❌ Ошибка в Promise.race:</strong> ${error.message}
        `, 'error');
    }
}

// 6.3. Создайте функцию fetchSequential, которая выполняет последовательные запросы
async function fetchSequential() {
    try {
        displayOutput('parallel-output', '<span class="loading"></span> Выполнение последовательных запросов...', 'warning');
        
        // Последовательное выполнение
        const userResponse = await fetch(`${API_BASE_URL}/users/1`);
        const user = await userResponse.json();
        
        const postsResponse = await fetch(`${API_BASE_URL}/posts?userId=1`);
        const posts = await postsResponse.json();
        
        const commentsResponse = await fetch(`${API_BASE_URL}/comments?postId=1`);
        const comments = await commentsResponse.json();
        
        displayOutput('parallel-output', `
            <strong>🔗 Последовательные запросы завершены:</strong>
            <div class="user-card">
                <h3>👤 ${user.name}</h3>
                <p><strong>Постов:</strong> ${posts.length}</p>
                <p><strong>Комментариев к первому посту:</strong> ${comments.length}</p>
            </div>
            <p><strong>Преимущества последовательных запросов:</strong></p>
            <ul class="header-list">
                <li>Зависимые данные (нужен userId для получения постов)</li>
                <li>Ограничение нагрузки на сервер</li>
                <li>Проще в отладке</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('parallel-output', `
            <strong>❌ Ошибка в последовательных запросах:</strong> ${error.message}
        `, 'error');
    }
}

// 6.4. Создайте функцию setupParallelRequests, которая настраивает обработчики
function setupParallelRequests() {
    document.getElementById('fetch-promise-all').addEventListener('click', fetchWithPromiseAll);
    document.getElementById('fetch-promise-race').addEventListener('click', fetchWithPromiseRace);
    document.getElementById('fetch-sequential').addEventListener('click', fetchSequential);
}

// ЗАДАНИЕ 7: Реальные сценарии

// 7.1. Создайте функцию fetchUserWithPosts, которая получает пользователя и его посты
async function fetchUserWithPosts() {
    try {
        displayOutput('scenario-output', '<span class="loading"></span> Загрузка пользователя и его постов...', 'warning');
        
        const [userResponse, postsResponse] = await Promise.all([
            fetch(`${API_BASE_URL}/users/1`),
            fetch(`${API_BASE_URL}/posts?userId=1`)
        ]);
        
        const [user, posts] = await Promise.all([
            userResponse.json(),
            postsResponse.json()
        ]);
        
        const postsHTML = posts.slice(0, 3).map(post => `
            <div class="user-card">
                <h4>📝 ${post.title}</h4>
                <p>${post.body.substring(0, 100)}...</p>
            </div>
        `).join('');
        
        displayOutput('scenario-output', `
            <strong>👤 Пользователь и его посты:</strong>
            <div class="user-card">
                <h3>${user.name}</h3>
                <p><strong>Email:</strong> ${user.email}</p>
                <p><strong>Компания:</strong> ${user.company.name}</p>
                <p><strong>Всего постов:</strong> ${posts.length}</p>
            </div>
            <h4>Последние посты:</h4>
            ${postsHTML}
        `, 'success');
        
    } catch (error) {
        displayOutput('scenario-output', `
            <strong>❌ Ошибка:</strong> ${error.message}
        `, 'error');
    }
}

// 7.2. Создайте функцию fetchWithSearch, которая реализует поиск
async function fetchWithSearch() {
    try {
        const searchTerm = 'sunt'; // Пример поискового запроса
        
        const response = await fetch(`${API_BASE_URL}/posts?q=${encodeURIComponent(searchTerm)}`);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const posts = await response.json();
        
        const postsHTML = posts.slice(0, 5).map(post => `
            <div class="user-card">
                <h4>📝 ${post.title}</h4>
                <p>${post.body}</p>
            </div>
        `).join('');
        
        displayOutput('scenario-output', `
            <strong>🔍 Результаты поиска по "${searchTerm}":</strong>
            <p><strong>Найдено постов:</strong> ${posts.length}</p>
            ${postsHTML}
        `, 'success');
        
    } catch (error) {
        displayOutput('scenario-output', `
            <strong>❌ Ошибка поиска:</strong> ${error.message}
        `, 'error');
    }
}

// 7.3. Создайте функцию fetchFileUpload, которая имитирует загрузку файла
async function fetchFileUpload() {
    try {
        // Создаем фиктивный файл для демонстрации
        const fileContent = 'Это содержимое текстового файла';
        const blob = new Blob([fileContent], { type: 'text/plain' });
        const file = new File([blob], 'example.txt', { type: 'text/plain' });
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('description', 'Пример загрузки файла');
        
        displayOutput('scenario-output', '<span class="loading"></span> Имитация загрузки файла...', 'warning');
        
        // В реальном приложении здесь был бы endpoint для загрузки файлов
        // Для демонстрации используем JSONPlaceholder
        const response = await fetch(`${API_BASE_URL}/posts`, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const result = await response.json();
        
        displayOutput('scenario-output', `
            <strong>📁 Загрузка файла имитирована:</strong>
            <p><strong>Имя файла:</strong> example.txt</p>
            <p><strong>Тип:</strong> text/plain</p>
            <p><strong>Размер:</strong> ${file.size} байт</p>
            <p><strong>Ответ сервера:</strong></p>
            <pre>${formatJSON(result)}</pre>
            <p><strong>Особенности загрузки файлов:</strong></p>
            <ul class="header-list">
                <li>Использование FormData</li>
                <li>Content-Type устанавливается автоматически</li>
                <li>Поддержка множественных файлов</li>
                <li>Прогресс загрузки через XMLHttpRequest.upload</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('scenario-output', `
            <strong>❌ Ошибка загрузки файла:</strong> ${error.message}
        `, 'error');
    }
}

// 7.4. Создайте функцию fetchWithCache, которая демонстрирует кэширование
async function fetchWithCache() {
    try {
        const cacheKey = 'cached-posts';
        
        // Проверяем кэш
        const cached = localStorage.getItem(cacheKey);
        const cacheTime = localStorage.getItem(`${cacheKey}-time`);
        const now = Date.now();
        const cacheExpiry = 5 * 60 * 1000; // 5 минут
        
        if (cached && cacheTime && (now - parseInt(cacheTime)) < cacheExpiry) {
            // Используем кэшированные данные
            const posts = JSON.parse(cached);
            displayOutput('scenario-output', `
                <strong>💾 Данные из кэша (создан ${Math.round((now - parseInt(cacheTime)) / 1000)} сек. назад):</strong>
                <p><strong>Постов в кэше:</strong> ${posts.length}</p>
                <pre>${formatJSON(posts.slice(0, 3))}</pre>
            `, 'success');
            return;
        }
        
        // Если кэш пустой или устарел, делаем запрос
        displayOutput('scenario-output', '<span class="loading"></span> Загрузка свежих данных...', 'warning');
        
        const response = await fetch(`${API_BASE_URL}/posts?_limit=5`);
        
        if (!response.ok) {
            throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        
        const posts = await response.json();
        
        // Сохраняем в кэш
        localStorage.setItem(cacheKey, JSON.stringify(posts));
        localStorage.setItem(`${cacheKey}-time`, now.toString());
        
        displayOutput('scenario-output', `
            <strong>🔄 Свежие данные загружены и сохранены в кэш:</strong>
            <p><strong>Постов загружено:</strong> ${posts.length}</p>
            <pre>${formatJSON(posts)}</pre>
            <p><strong>Кэширование полезно для:</strong></p>
            <ul class="header-list">
                <li>Уменьшения количества запросов</li>
                <li>Ускорения загрузки</li>
                <li>Работы офлайн</li>
                <li>Снижения нагрузки на сервер</li>
            </ul>
        `, 'success');
        
    } catch (error) {
        displayOutput('scenario-output', `
            <strong>❌ Ошибка кэширования:</strong> ${error.message}
        `, 'error');
    }
}

// 7.5. Создайте функцию setupRealScenarios, которая настраивает обработчики
function setupRealScenarios() {
    document.getElementById('fetch-user-posts').addEventListener('click', fetchUserWithPosts);
    document.getElementById('fetch-search').addEventListener('click', fetchWithSearch);
    document.getElementById('fetch-file-upload').addEventListener('click', fetchFileUpload);
    document.getElementById('fetch-cache').addEventListener('click', fetchWithCache);
}

// Экспортируем функции для тестирования
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        fetchGetRequest,
        fetchJsonData,
        fetchPostRequest,
        fetchPutRequest,
        fetchPatchRequest,
        fetchDeleteRequest,
        fetchWithHeaders,
        fetchWithAuth,
        fetchWithParams,
        fetchWithTimeout,
        fetchAndCheckStatus,
        fetchAndReadHeaders,
        fetchBlobData,
        fetchWithFormData,
        fetchNetworkError,
        fetchHttpError,
        fetchWithAbort,
        fetchWithRetry,
        fetchWithPromiseAll,
        fetchWithPromiseRace,
        fetchSequential,
        fetchUserWithPosts,
        fetchWithSearch,
        fetchFileUpload,
        fetchWithCache
    };
}
// === АСИНХРОННЫЕ ОПЕРАЦИИ - ОСНОВНЫЕ ЗАДАНИЯ ===

// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
function logToOutput(selector, message, type = 'info') {
    const output = document.querySelector(selector);
    const timestamp = new Date().toLocaleTimeString();
    const formattedMessage = `[${timestamp}] ${message}`;
    
    const messageElement = document.createElement('div');
    messageElement.textContent = formattedMessage;
    
    if (type === 'error') {
        messageElement.className = 'error';
    } else if (type === 'success') {
        messageElement.className = 'success';
    } else if (type === 'loading') {
        messageElement.className = 'loading';
    }
    
    output.appendChild(messageElement);
    output.scrollTop = output.scrollHeight;
}

function clearOutput(selector) {
    const output = document.querySelector(selector);
    output.innerHTML = '';
}

// ЗАДАНИЕ 1: Основы промисов

// 1.1. Создайте функцию createBasicPromise, которая возвращает промис
function createBasicPromise(shouldResolve = true) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (shouldResolve) {
                resolve("Успех! Промис выполнен корректно.");
            } else {
                reject("Ошибка! Промис завершился с ошибкой.");
            }
        }, 1000);
    });
}

// 1.2. Создайте функцию handleBasicPromise, которая обрабатывает промис
function handleBasicPromise() {
    clearOutput('#promise-output');
    logToOutput('#promise-output', 'Запуск базового промиса...', 'loading');
    
    createBasicPromise(true)
        .then(result => {
            logToOutput('#promise-output', `✅ ${result}`, 'success');
        })
        .catch(error => {
            logToOutput('#promise-output', `❌ ${error}`, 'error');
        });
}

// 1.3. Создайте функцию createPromiseChain, которая демонстрирует цепочку промисов
function createPromiseChain() {
    clearOutput('#promise-output');
    logToOutput('#promise-output', 'Запуск цепочки промисов...', 'loading');
    
    createBasicPromise(true)
        .then(result => {
            logToOutput('#promise-output', `Шаг 1: ${result}`, 'success');
            return new Promise(resolve => {
                setTimeout(() => resolve(`${result} -> Шаг 2 выполнен`), 500);
            });
        })
        .then(result => {
            logToOutput('#promise-output', `Шаг 2: ${result}`, 'success');
            return new Promise(resolve => {
                setTimeout(() => resolve(`${result} -> Шаг 3 выполнен`), 500);
            });
        })
        .then(result => {
            logToOutput('#promise-output', `Шаг 3: ${result}`, 'success');
            logToOutput('#promise-output', '✅ Цепочка промисов завершена!', 'success');
        })
        .catch(error => {
            logToOutput('#promise-output', `❌ Ошибка в цепочке: ${error}`, 'error');
        });
}

// 1.4. Создайте функцию handlePromiseError, которая обрабатывает ошибки в промисах
function handlePromiseError() {
    clearOutput('#promise-output');
    logToOutput('#promise-output', 'Тестирование обработки ошибок...', 'loading');
    
    createBasicPromise(false)
        .then(result => {
            logToOutput('#promise-output', `✅ ${result}`, 'success');
        })
        .catch(error => {
            logToOutput('#promise-output', `❌ Перехвачена ошибка: ${error}`, 'error');
        });
}

// 1.5. Создайте функцию setupPromiseEvents, которая настраивает обработчики
function setupPromiseEvents() {
    document.getElementById('basic-promise').addEventListener('click', handleBasicPromise);
    document.getElementById('promise-chain').addEventListener('click', createPromiseChain);
    document.getElementById('promise-error').addEventListener('click', handlePromiseError);
}

// ЗАДАНИЕ 2: Async/Await

// 2.1. Создайте функцию basicAsyncAwait, которая использует async/await
async function basicAsyncAwait() {
    clearOutput('#async-output');
    logToOutput('#async-output', 'Запуск async/await функции...', 'loading');
    
    try {
        await new Promise(resolve => setTimeout(resolve, 500));
        const result = await createBasicPromise(true);
        logToOutput('#async-output', `✅ ${result}`, 'success');
    } catch (error) {
        logToOutput('#async-output', `❌ ${error}`, 'error');
    }
}

// 2.2. Создайте функцию handleAsyncError с try/catch
async function handleAsyncError() {
    clearOutput('#async-output');
    logToOutput('#async-output', 'Тестирование обработки ошибок с async/await...', 'loading');
    
    try {
        const result = await createBasicPromise(false);
        logToOutput('#async-output', `✅ ${result}`, 'success');
    } catch (error) {
        logToOutput('#async-output', `❌ Перехвачена ошибка: ${error}`, 'error');
    }
}

// 2.3. Создайте функцию parallelAsyncExecution для параллельного выполнения
async function parallelAsyncExecution() {
    clearOutput('#async-output');
    logToOutput('#async-output', 'Запуск параллельного выполнения...', 'loading');
    
    const startTime = Date.now();
    
    try {
        const promises = [
            new Promise(resolve => setTimeout(() => resolve("Задача 1 выполнена"), 800)),
            new Promise(resolve => setTimeout(() => resolve("Задача 2 выполнена"), 600)),
            new Promise(resolve => setTimeout(() => resolve("Задача 3 выполнена"), 400))
        ];
        
        const results = await Promise.all(promises);
        const endTime = Date.now();
        const duration = endTime - startTime;
        
        results.forEach((result, index) => {
            logToOutput('#async-output', `✅ ${result}`, 'success');
        });
        
        logToOutput('#async-output', `⏱️ Все задачи выполнены за ${duration}мс`, 'success');
    } catch (error) {
        logToOutput('#async-output', `❌ Ошибка: ${error}`, 'error');
    }
}

// 2.4. Создайте функцию setupAsyncEvents, которая настраивает обработчики
function setupAsyncEvents() {
    document.getElementById('basic-async').addEventListener('click', basicAsyncAwait);
    document.getElementById('async-error').addEventListener('click', handleAsyncError);
    document.getElementById('async-parallel').addEventListener('click', parallelAsyncExecution);
}

// ЗАДАНИЕ 3: Работа с внешними API

// 3.1. Создайте функцию fetchUsers, которая загружает пользователей с JSONPlaceholder API
async function fetchUsers() {
    clearOutput('#api-output');
    clearOutput('#api-data');
    logToOutput('#api-output', 'Загрузка пользователей...', 'loading');
    
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const users = await response.json();
        logToOutput('#api-output', `✅ Загружено ${users.length} пользователей`, 'success');
        
        const dataContainer = document.getElementById('api-data');
        users.forEach(user => {
            const userCard = document.createElement('div');
            userCard.className = 'user-card';
            userCard.innerHTML = `
                <h4>${user.name}</h4>
                <p><strong>Email:</strong> ${user.email}</p>
                <p><strong>Телефон:</strong> ${user.phone}</p>
                <p><strong>Компания:</strong> ${user.company.name}</p>
                <p><strong>Город:</strong> ${user.address.city}</p>
            `;
            dataContainer.appendChild(userCard);
        });
    } catch (error) {
        logToOutput('#api-output', `❌ Ошибка при загрузке пользователей: ${error.message}`, 'error');
    }
}

// 3.2. Создайте функцию createPost, которая отправляет POST запрос
async function createPost() {
    clearOutput('#api-output');
    logToOutput('#api-output', 'Отправка POST запроса...', 'loading');
    
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title: 'Новый пост',
                body: 'Это тело нового поста, созданного через fetch API.',
                userId: 1
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        logToOutput('#api-output', '✅ Пост успешно создан!', 'success');
        logToOutput('#api-output', `ID: ${data.id}, Title: ${data.title}`, 'success');
    } catch (error) {
        logToOutput('#api-output', `❌ Ошибка при создании поста: ${error.message}`, 'error');
    }
}

// 3.3. Создайте функцию testApiError, которая тестирует обработку ошибок API
async function testApiError() {
    clearOutput('#api-output');
    logToOutput('#api-output', 'Тестирование обработки ошибок API...', 'loading');
    
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/nonexistent');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        logToOutput('#api-output', `✅ Данные получены: ${JSON.stringify(data)}`, 'success');
    } catch (error) {
        logToOutput('#api-output', `❌ Ошибка API: ${error.message}`, 'error');
        
        if (error.message.includes('404')) {
            logToOutput('#api-output', '🔍 Страница не найдена (404)', 'error');
        } else if (error.message.includes('network')) {
            logToOutput('#api-output', '🌐 Проблема с сетью', 'error');
        } else {
            logToOutput('#api-output', '⚠️ Неизвестная ошибка', 'error');
        }
    }
}

// 3.4. Создайте функцию setupApiEvents, которая настраивает обработчики API
function setupApiEvents() {
    document.getElementById('fetch-users').addEventListener('click', fetchUsers);
    document.getElementById('fetch-post').addEventListener('click', createPost);
    document.getElementById('fetch-error').addEventListener('click', testApiError);
}

// ЗАДАНИЕ 4: Асинхронные таймеры

let intervalId;
let intervalCounter = 0;

// 4.1. Создайте функцию startAsyncInterval, которая запускает асинхронный интервал
async function startAsyncInterval() {
    clearOutput('#interval-output');
    logToOutput('#interval-output', 'Запуск асинхронного интервала...', 'loading');
    
    intervalCounter = 0;
    intervalId = setInterval(async () => {
        intervalCounter++;
        const output = document.getElementById('interval-output');
        output.innerHTML = `Счетчик: ${intervalCounter}<br>Последнее обновление: ${new Date().toLocaleTimeString()}`;
        
        // Имитация асинхронной операции
        await new Promise(resolve => setTimeout(resolve, 100));
    }, 1000);
}

// 4.2. Создайте функцию stopAsyncInterval, которая останавливает интервал
function stopAsyncInterval() {
    if (intervalId) {
        clearInterval(intervalId);
        logToOutput('#interval-output', `⏹️ Интервал остановлен. Финальный счетчик: ${intervalCounter}`, 'success');
        intervalCounter = 0;
    }
}

// 4.3. Создайте функцию delayWithPromise, которая создает задержку с промисом
function delayWithPromise(ms) {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(`Задержка ${ms}мс завершена`);
        }, ms);
    });
}

// 4.4. Создайте функцию testDelay, которая тестирует задержку
async function testDelay() {
    clearOutput('#timer-output');
    logToOutput('#timer-output', 'Тестирование последовательных задержек...', 'loading');
    
    try {
        logToOutput('#timer-output', 'Запуск задержки 500мс...', 'loading');
        await delayWithPromise(500);
        logToOutput('#timer-output', '✅ 500мс завершено', 'success');
        
        logToOutput('#timer-output', 'Запуск задержки 1000мс...', 'loading');
        await delayWithPromise(1000);
        logToOutput('#timer-output', '✅ 1000мс завершено', 'success');
        
        logToOutput('#timer-output', 'Запуск задержки 1500мс...', 'loading');
        await delayWithPromise(1500);
        logToOutput('#timer-output', '✅ 1500мс завершено', 'success');
        
        logToOutput('#timer-output', '🎉 Все задержки завершены!', 'success');
    } catch (error) {
        logToOutput('#timer-output', `❌ Ошибка: ${error}`, 'error');
    }
}

// 4.5. Создайте функцию setupTimerEvents, которая настраивает обработчики таймеров
function setupTimerEvents() {
    document.getElementById('start-interval').addEventListener('click', startAsyncInterval);
    document.getElementById('stop-interval').addEventListener('click', stopAsyncInterval);
    document.getElementById('delay-promise').addEventListener('click', testDelay);
}

// ЗАДАНИЕ 5: Обработка ошибок

// 5.1. Создайте функцию asyncTryCatch, которая демонстрирует try/catch с async
async function asyncTryCatch() {
    clearOutput('#error-output');
    logToOutput('#error-output', 'Тестирование вложенных try/catch блоков...', 'loading');
    
    try {
        logToOutput('#error-output', 'Внешний блок: начало', 'info');
        
        try {
            logToOutput('#error-output', 'Внутренний блок 1: выполнение операции...', 'loading');
            await createBasicPromise(true);
            logToOutput('#error-output', '✅ Внутренний блок 1: успех', 'success');
        } catch (error) {
            logToOutput('#error-output', `❌ Внутренний блок 1: ${error}`, 'error');
        }
        
        try {
            logToOutput('#error-output', 'Внутренний блок 2: выполнение операции с ошибкой...', 'loading');
            await createBasicPromise(false);
            logToOutput('#error-output', '✅ Внутренний блок 2: успех', 'success');
        } catch (error) {
            logToOutput('#error-output', `❌ Внутренний блок 2: ${error}`, 'error');
        }
        
        logToOutput('#error-output', '✅ Внешний блок: все операции завершены', 'success');
    } catch (error) {
        logToOutput('#error-output', `❌ Внешний блок: ${error}`, 'error');
    }
}

// 5.2. Создайте функцию handleMultipleErrors, которая обрабатывает множественные ошибки
async function handleMultipleErrors() {
    clearOutput('#error-output');
    logToOutput('#error-output', 'Тестирование множественных ошибок...', 'loading');
    
    const promises = [
        createBasicPromise(true),
        createBasicPromise(false),
        createBasicPromise(true),
        createBasicPromise(false),
        createBasicPromise(true)
    ];
    
    const results = await Promise.allSettled(promises);
    
    let successCount = 0;
    let errorCount = 0;
    
    results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
            logToOutput('#error-output', `✅ Промис ${index + 1}: ${result.value}`, 'success');
            successCount++;
        } else {
            logToOutput('#error-output', `❌ Промис ${index + 1}: ${result.reason}`, 'error');
            errorCount++;
        }
    });
    
    logToOutput('#error-output', `📊 Статистика: Успешно ${successCount}, Ошибок ${errorCount}`, 'info');
}

// 5.3. Создайте функцию retryWithBackoff, которая реализует повторные попытки
async function retryWithBackoff(operation, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            logToOutput('#error-output', `Попытка ${attempt}/${maxRetries}...`, 'loading');
            const result = await operation();
            logToOutput('#error-output', `✅ Попытка ${attempt} успешна!`, 'success');
            return result;
        } catch (error) {
            logToOutput('#error-output', `❌ Попытка ${attempt} failed: ${error}`, 'error');
            
            if (attempt === maxRetries) {
                throw new Error(`Все ${maxRetries} попытки завершились ошибкой`);
            }
            
            const delay = Math.pow(2, attempt) * 1000;
            logToOutput('#error-output', `⏳ Ожидание ${delay}мс перед следующей попыткой...`, 'loading');
            await delayWithPromise(delay);
        }
    }
}

// 5.4. Создайте функцию setupErrorEvents, которая настраивает обработчики ошибок
function setupErrorEvents() {
    document.getElementById('try-catch').addEventListener('click', asyncTryCatch);
    document.getElementById('multiple-errors').addEventListener('click', handleMultipleErrors);
    document.getElementById('retry-pattern').addEventListener('click', async () => {
        clearOutput('#error-output');
        logToOutput('#error-output', 'Тестирование повторных попыток...', 'loading');
        
        const failingOperation = () => createBasicPromise(false);
        
        try {
            await retryWithBackoff(failingOperation, 3);
        } catch (error) {
            logToOutput('#error-output', `💥 Финальная ошибка: ${error.message}`, 'error');
        }
    });
}

// ЗАДАНИЕ 6: Параллельные операции

// 6.1. Создайте функцию demonstratePromiseAll, которая использует Promise.all
async function demonstratePromiseAll() {
    clearOutput('#parallel-output');
    logToOutput('#parallel-output', 'Демонстрация Promise.all...', 'loading');
    
    const startTime = Date.now();
    
    const promises = [
        delayWithPromise(1000).then(() => 'Задача 1 (1000мс)'),
        delayWithPromise(500).then(() => 'Задача 2 (500мс)'),
        delayWithPromise(800).then(() => 'Задача 3 (800мс)'),
        delayWithPromise(300).then(() => 'Задача 4 (300мс)'),
        delayWithPromise(1200).then(() => 'Задача 5 (1200мс)')
    ];
    
    try {
        const results = await Promise.all(promises);
        const endTime = Date.now();
        const duration = endTime - startTime;
        
        results.forEach((result, index) => {
            logToOutput('#parallel-output', `✅ ${result}`, 'success');
        });
        
        logToOutput('#parallel-output', `⏱️ Promise.all завершен за ${duration}мс (максимальное время)`, 'success');
    } catch (error) {
        logToOutput('#parallel-output', `❌ Ошибка в Promise.all: ${error}`, 'error');
    }
}

// 6.2. Создайте функцию demonstratePromiseRace, которая использует Promise.race
async function demonstratePromiseRace() {
    clearOutput('#parallel-output');
    logToOutput('#parallel-output', 'Демонстрация Promise.race...', 'loading');
    
    const promises = [
        delayWithPromise(1000).then(() => 'Медленная задача (1000мс)'),
        delayWithPromise(300).then(() => 'Быстрая задача (300мс)'),
        delayWithPromise(500).then(() => 'Средняя задача (500мс)')
    ];
    
    try {
        const winner = await Promise.race(promises);
        logToOutput('#parallel-output', `🏆 Победитель гонки: ${winner}`, 'success');
        
        // Покажем все результаты
        const allResults = await Promise.all(promises);
        allResults.forEach(result => {
            logToOutput('#parallel-output', `📋 ${result}`, 'info');
        });
    } catch (error) {
        logToOutput('#parallel-output', `❌ Ошибка в Promise.race: ${error}`, 'error');
    }
}

// 6.3. Создайте функцию demonstratePromiseAllSettled, которая использует Promise.allSettled
async function demonstratePromiseAllSettled() {
    clearOutput('#parallel-output');
    logToOutput('#parallel-output', 'Демонстрация Promise.allSettled...', 'loading');
    
    const promises = [
        createBasicPromise(true),
        createBasicPromise(false),
        createBasicPromise(true),
        createBasicPromise(false),
        createBasicPromise(true)
    ];
    
    const results = await Promise.allSettled(promises);
    
    results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
            logToOutput('#parallel-output', `✅ Промис ${index + 1}: ${result.value}`, 'success');
        } else {
            logToOutput('#parallel-output', `❌ Промис ${index + 1}: ${result.reason}`, 'error');
        }
    });
    
    const fulfilledCount = results.filter(r => r.status === 'fulfilled').length;
    const rejectedCount = results.filter(r => r.status === 'rejected').length;
    
    logToOutput('#parallel-output', `📊 Итог: ${fulfilledCount} успешно, ${rejectedCount} с ошибками`, 'info');
}

// 6.4. Создайте функцию setupParallelEvents, которая настраивает обработчики
function setupParallelEvents() {
    document.getElementById('promise-all').addEventListener('click', demonstratePromiseAll);
    document.getElementById('promise-race').addEventListener('click', demonstratePromiseRace);
    document.getElementById('promise-allSettled').addEventListener('click', demonstratePromiseAllSettled);
}

// ЗАДАНИЕ 7: Реальные сценарии

// 7.1. Создайте функцию sequentialApiRequests, которая делает последовательные запросы
async function sequentialApiRequests() {
    clearOutput('#scenario-output');
    logToOutput('#scenario-output', 'Запуск последовательных API запросов...', 'loading');
    
    try {
        // 1. Получить пользователя
        logToOutput('#scenario-output', '1. Получение пользователя...', 'loading');
        const userResponse = await fetch('https://jsonplaceholder.typicode.com/users/1');
        const user = await userResponse.json();
        logToOutput('#scenario-output', `✅ Пользователь: ${user.name}`, 'success');
        
        // 2. Получить посты пользователя
        logToOutput('#scenario-output', '2. Получение постов пользователя...', 'loading');
        const postsResponse = await fetch(`https://jsonplaceholder.typicode.com/posts?userId=${user.id}`);
        const posts = await postsResponse.json();
        logToOutput('#scenario-output', `✅ Получено постов: ${posts.length}`, 'success');
        
        // 3. Получить комментарии к первому посту
        if (posts.length > 0) {
            logToOutput('#scenario-output', '3. Получение комментариев к первому посту...', 'loading');
            const commentsResponse = await fetch(`https://jsonplaceholder.typicode.com/comments?postId=${posts[0].id}`);
            const comments = await commentsResponse.json();
            logToOutput('#scenario-output', `✅ Получено комментариев: ${comments.length}`, 'success');
            
            logToOutput('#scenario-output', '🎉 Все последовательные запросы завершены!', 'success');
            logToOutput('#scenario-output', `📊 Итог: Пользователь "${user.name}", ${posts.length} постов, ${comments.length} комментариев`, 'success');
        }
    } catch (error) {
        logToOutput('#scenario-output', `❌ Ошибка в последовательных запросах: ${error.message}`, 'error');
    }
}

// 7.2. Создайте функцию simulateFileUpload, которая симулирует загрузку файла
async function simulateFileUpload() {
    clearOutput('#scenario-output');
    logToOutput('#scenario-output', 'Симуляция загрузки файла...', 'loading');
    
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');
    
    let progress = 0;
    
    return new Promise((resolve) => {
        const interval = setInterval(() => {
            progress += Math.random() * 10;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                logToOutput('#scenario-output', '✅ Загрузка файла завершена!', 'success');
                resolve();
            }
            
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `${Math.round(progress)}%`;
        }, 200);
    });
}

// 7.3. Создайте функцию cachedApiRequest, которая реализует кэширование запросов
function createCachedApiRequest() {
    const cache = new Map();
    
    return async function cachedRequest(url) {
        if (cache.has(url)) {
            logToOutput('#scenario-output', `📦 Использование кэша для: ${url}`, 'success');
            return cache.get(url);
        }
        
        logToOutput('#scenario-output', `🌐 Загрузка данных для: ${url}`, 'loading');
        const response = await fetch(url);
        const data = await response.json();
        
        cache.set(url, data);
        logToOutput('#scenario-output', `✅ Данные загружены и сохранены в кэш: ${url}`, 'success');
        
        return data;
    };
}

// 7.4. Создайте функцию setupRealScenarioEvents, которая настраивает обработчики
function setupRealScenarioEvents() {
    const cachedRequest = createCachedApiRequest();
    
    document.getElementById('sequential-requests').addEventListener('click', sequentialApiRequests);
    document.getElementById('upload-simulation').addEventListener('click', simulateFileUpload);
    document.getElementById('cache-requests').addEventListener('click', async () => {
        clearOutput('#scenario-output');
        logToOutput('#scenario-output', 'Тестирование кэширования запросов...', 'loading');
        
        try {
            // Первый запрос - загрузит данные
            await cachedRequest('https://jsonplaceholder.typicode.com/users/1');
            
            // Второй запрос - использует кэш
            await cachedRequest('https://jsonplaceholder.typicode.com/users/1');
            
            // Третий запрос - загрузит новые данные
            await cachedRequest('https://jsonplaceholder.typicode.com/users/2');
            
            logToOutput('#scenario-output', '🎉 Тестирование кэширования завершено!', 'success');
        } catch (error) {
            logToOutput('#scenario-output', `❌ Ошибка: ${error.message}`, 'error');
        }
    });
}
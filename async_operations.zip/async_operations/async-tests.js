// Тесты для асинхронных операций
// Практическая работа №13

console.log('🚀 Запуск тестов для асинхронных операций...');

// Вспомогательные функции для тестирования
class AsyncTests {
    constructor() {
        this.passed = 0;
        this.failed = 0;
        this.total = 0;
    }

    assert(condition, message) {
        this.total++;
        if (condition) {
            console.log(`✅ PASS: ${message}`);
            this.passed++;
        } else {
            console.log(`❌ FAIL: ${message}`);
            this.failed++;
        }
    }

    async assertAsync(promise, expected, message) {
        this.total++;
        try {
            const result = await promise;
            if (result === expected || (typeof expected === 'function' && expected(result))) {
                console.log(`✅ PASS: ${message}`);
                this.passed++;
            } else {
                console.log(`❌ FAIL: ${message} - Expected: ${expected}, Got: ${result}`);
                this.failed++;
            }
        } catch (error) {
            console.log(`❌ FAIL: ${message} - Error: ${error.message}`);
            this.failed++;
        }
    }

    summary() {
        console.log('\n📊 ИТОГИ ТЕСТИРОВАНИЯ:');
        console.log(`Всего тестов: ${this.total}`);
        console.log(`Пройдено: ${this.passed}`);
        console.log(`Провалено: ${this.failed}`);
        console.log(`Успешность: ${((this.passed / this.total) * 100).toFixed(2)}%`);
        
        if (this.failed === 0) {
            console.log('🎉 Все тесты пройдены успешно!');
        } else {
            console.log('⚠️ Некоторые тесты провалились');
        }
    }
}

// Создаем экземпляр тестов
const tests = new AsyncTests();

// Тестируем базовые промисы
async function testBasicPromises() {
    console.log('\n=== ТЕСТИРОВАНИЕ БАЗОВЫХ ПРОМИСОВ ===');
    
    // Тест 1: Успешное выполнение промиса
    await tests.assertAsync(
        createBasicPromise(true),
        "Успех! Промис выполнен корректно.",
        "Промис должен выполниться успешно"
    );
    
    // Тест 2: Ошибка в промисе
    try {
        await createBasicPromise(false);
        tests.assert(false, "Промис должен был завершиться ошибкой");
    } catch (error) {
        tests.assert(error === "Ошибка! Промис завершился с ошибкой.", "Промис должен вернуть ошибку");
    }
    
    // Тест 3: Задержка выполнения
    const startTime = Date.now();
    await createBasicPromise(true);
    const duration = Date.now() - startTime;
    tests.assert(duration >= 900 && duration <= 1100, `Промис должен выполняться ~1000мс (выполнен за ${duration}мс)`);
}

// Тестируем цепочки промисов
async function testPromiseChains() {
    console.log('\n=== ТЕСТИРОВАНИЕ ЦЕПОЧЕК ПРОМИСОВ ===');
    
    let chainResult = "";
    await createBasicPromise(true)
        .then(result => {
            chainResult += result + " -> ";
            return new Promise(resolve => setTimeout(() => resolve("Шаг 2"), 100));
        })
        .then(result => {
            chainResult += result + " -> ";
            return new Promise(resolve => setTimeout(() => resolve("Шаг 3"), 100));
        })
        .then(result => {
            chainResult += result;
        });
    
    tests.assert(
        chainResult.includes("Успех!") && chainResult.includes("Шаг 2") && chainResult.includes("Шаг 3"),
        "Цепочка промисов должна корректно передавать результаты"
    );
}

// Тестируем async/await
async function testAsyncAwait() {
    console.log('\n=== ТЕСТИРОВАНИЕ ASYNC/AWAIT ===');
    
    // Тест 1: Базовый async/await
    async function testBasicAsync() {
        const result = await createBasicPromise(true);
        return result;
    }
    
    await tests.assertAsync(
        testBasicAsync(),
        "Успех! Промис выполнен корректно.",
        "Async/await должен корректно работать с промисами"
    );
    
    // Тест 2: Обработка ошибок в async/await
    async function testAsyncError() {
        try {
            await createBasicPromise(false);
            return "Успех";
        } catch (error) {
            return "Ошибка перехвачена";
        }
    }
    
    await tests.assertAsync(
        testAsyncError(),
        "Ошибка перехвачена",
        "Async/await должен корректно перехватывать ошибки"
    );
}

// Тестируем параллельное выполнение
async function testParallelExecution() {
    console.log('\n=== ТЕСТИРОВАНИЕ ПАРАЛЛЕЛЬНОГО ВЫПОЛНЕНИЯ ===');
    
    // Тест Promise.all
    const promises = [
        delayWithPromise(100).then(() => "Задача 1"),
        delayWithPromise(200).then(() => "Задача 2"),
        delayWithPromise(150).then(() => "Задача 3")
    ];
    
    const startTime = Date.now();
    const results = await Promise.all(promises);
    const duration = Date.now() - startTime;
    
    tests.assert(
        duration >= 190 && duration <= 250,
        `Promise.all должен выполняться за время самой долгой задачи (выполнен за ${duration}мс)`
    );
    
    tests.assert(
        results.length === 3 && results.every(r => r.startsWith("Задача")),
        "Promise.all должен вернуть все результаты"
    );
    
    // Тест Promise.race
    const racePromises = [
        delayWithPromise(300).then(() => "Медленный"),
        delayWithPromise(100).then(() => "Быстрый"),
        delayWithPromise(200).then(() => "Средний")
    ];
    
    const winner = await Promise.race(racePromises);
    tests.assert(winner === "Быстрый", "Promise.race должен вернуть первый завершенный промис");
    
    // Тест Promise.allSettled
    const settledPromises = [
        createBasicPromise(true),
        createBasicPromise(false),
        createBasicPromise(true)
    ];
    
    const settledResults = await Promise.allSettled(settledPromises);
    const fulfilledCount = settledResults.filter(r => r.status === 'fulfilled').length;
    const rejectedCount = settledResults.filter(r => r.status === 'rejected').length;
    
    tests.assert(fulfilledCount === 2 && rejectedCount === 1, "Promise.allSettled должен обработать все промисы независимо от результата");
}

// Тестируем работу с API
async function testApiOperations() {
    console.log('\n=== ТЕСТИРОВАНИЕ РАБОТЫ С API ===');
    
    // Тест получения пользователей
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
        tests.assert(response.ok, "API запрос должен быть успешным");
        
        const user = await response.json();
        tests.assert(typeof user === 'object' && user.id === 1, "Должен вернуться корректный пользователь");
        tests.assert(user.hasOwnProperty('name'), "Пользователь должен иметь поле name");
        tests.assert(user.hasOwnProperty('email'), "Пользователь должен иметь поле email");
    } catch (error) {
        tests.assert(false, `API запрос не должен падать с ошибкой: ${error.message}`);
    }
    
    // Тест создания поста
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title: 'Test Post',
                body: 'Test Body',
                userId: 1
            })
        });
        
        tests.assert(response.ok, "POST запрос должен быть успешным");
        
        const post = await response.json();
        tests.assert(post.hasOwnProperty('id'), "Созданный пост должен иметь ID");
        tests.assert(post.title === 'Test Post', "Пост должен иметь корректный заголовок");
    } catch (error) {
        tests.assert(false, `POST запрос не должен падать с ошибкой: ${error.message}`);
    }
}

// Тестируем обработку ошибок
async function testErrorHandling() {
    console.log('\n=== ТЕСТИРОВАНИЕ ОБРАБОТКИ ОШИБОК ===');
    
    // Тест повторных попыток
    let attemptCount = 0;
    const failingOperation = () => {
        attemptCount++;
        return createBasicPromise(false);
    };
    
    try {
        await retryWithBackoff(failingOperation, 3);
        tests.assert(false, "Повторные попытки должны завершиться ошибкой");
    } catch (error) {
        tests.assert(attemptCount === 3, `Должно быть 3 попытки (было: ${attemptCount})`);
        tests.assert(error.message.includes("3 попытки"), "Ошибка должна содержать информацию о количестве попыток");
    }
    
    // Тест успешных повторных попыток
    let successAttempts = 0;
    const eventuallySuccessfulOperation = () => {
        successAttempts++;
        if (successAttempts < 3) {
            return createBasicPromise(false);
        } else {
            return createBasicPromise(true);
        }
    };
    
    try {
        const result = await retryWithBackoff(eventuallySuccessfulOperation, 3);
        tests.assert(successAttempts === 3, `Должно быть 3 попытки до успеха (было: ${successAttempts})`);
        tests.assert(result === "Успех! Промис выполнен корректно.", "Должен вернуться успешный результат");
    } catch (error) {
        tests.assert(false, "Операция должна завершиться успешно после 3 попыток");
    }
}

// Тестируем таймеры и задержки
async function testTimers() {
    console.log('\n=== ТЕСТИРОВАНИЕ ТАЙМЕРОВ И ЗАДЕРЖЕК ===');
    
    // Тест функции задержки
    const startTime = Date.now();
    await delayWithPromise(100);
    const duration = Date.now() - startTime;
    
    tests.assert(
        duration >= 90 && duration <= 120,
        `Задержка должна быть примерно 100мс (получилось: ${duration}мс)`
    );
    
    // Тест что delayWithPromise возвращает промис
    const promise = delayWithPromise(50);
    tests.assert(promise instanceof Promise, "delayWithPromise должен возвращать Promise");
    
    // Тест разрешения промиса
    const result = await promise;
    tests.assert(result.includes("завершена"), "Промис задержки должен разрешаться с сообщением");
}

// Тестируем кэширование
async function testCaching() {
    console.log('\n=== ТЕСТИРОВАНИЕ КЭШИРОВАНИЯ ===');
    
    const cachedRequest = createCachedApiRequest();
    let fetchCount = 0;
    
    // Мокаем fetch для тестирования
    const originalFetch = window.fetch;
    window.fetch = async (url) => {
        fetchCount++;
        return {
            ok: true,
            json: async () => ({ data: `response from ${url}` })
        };
    };
    
    try {
        // Первый запрос - должен вызвать fetch
        await cachedRequest('https://api.example.com/data1');
        tests.assert(fetchCount === 1, "Первый запрос должен вызвать fetch");
        
        // Второй запрос - должен использовать кэш
        await cachedRequest('https://api.example.com/data1');
        tests.assert(fetchCount === 1, "Второй запрос должен использовать кэш");
        
        // Третий запрос на другой URL - снова должен вызвать fetch
        await cachedRequest('https://api.example.com/data2');
        tests.assert(fetchCount === 2, "Запрос на другой URL должен вызвать fetch");
        
    } finally {
        // Восстанавливаем оригинальный fetch
        window.fetch = originalFetch;
    }
}

// Краевые случаи
async function testEdgeCases() {
    console.log('\n=== ТЕСТИРОВАНИЕ КРАЕВЫХ СЛУЧАЕВ ===');
    
    // Тест с нулевой задержкой
    await tests.assertAsync(
        delayWithPromise(0),
        result => result.includes("завершена"),
        "Задержка 0мс должна работать"
    );
    
    // Тест с очень большой задержкой (сокращенной для тестов)
    const startTime = Date.now();
    await delayWithPromise(100); // Используем 100мс вместо реально большой задержки
    const duration = Date.now() - startTime;
    tests.assert(duration >= 90, "Большая задержка должна соблюдаться");
    
    // Тест с пустым массивом в Promise.all
    const emptyResults = await Promise.all([]);
    tests.assert(Array.isArray(emptyResults) && emptyResults.length === 0, "Promise.all с пустым массивом должен вернуть пустой массив");
    
    // Тест с немедленно разрешающимся промисом
    const immediatePromise = Promise.resolve("Мгновенный результат");
    await tests.assertAsync(
        immediatePromise,
        "Мгновенный результат",
        "Немедленно разрешающиеся промисы должны работать"
    );
}

// Запуск всех тестов
async function runAllTests() {
    console.log('🧪 ЗАПУСК ВСЕХ ТЕСТОВ...\n');
    
    try {
        await testBasicPromises();
        await testPromiseChains();
        await testAsyncAwait();
        await testParallelExecution();
        await testApiOperations();
        await testErrorHandling();
        await testTimers();
        await testCaching();
        await testEdgeCases();
        
        console.log('\n' + '='.repeat(50));
        tests.summary();
        
    } catch (error) {
        console.error('💥 Критическая ошибка при выполнении тестов:', error);
    }
}

// Функция для ручного запуска тестов из консоли
window.runAsyncTests = runAllTests;

// Автоматический запуск тестов при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Даем время на загрузку страницы, затем запускаем тесты
    setTimeout(() => {
        console.log('🔧 Для запуска тестов введите: runAsyncTests()');
        console.log('🔧 Или они запустятся автоматически через 3 секунды...');
        
        // Автозапуск через 3 секунды
        setTimeout(runAllTests, 3000);
    }, 1000);
});

// Экспортируем для использования в других модулях (если нужно)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        tests,
        runAllTests,
        testBasicPromises,
        testPromiseChains,
        testAsyncAwait,
        testParallelExecution,
        testApiOperations,
        testErrorHandling,
        testTimers,
        testCaching,
        testEdgeCases
    };
}